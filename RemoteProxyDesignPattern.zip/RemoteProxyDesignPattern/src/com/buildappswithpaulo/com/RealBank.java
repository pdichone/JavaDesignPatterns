package com.buildappswithpaulo.com;

public class RealBank implements Bank {
    @Override
    public void withdrawMoney(String clientName) throws Exception {
        System.out.println(clientName + " is withdrawing from the ATM....");
    }
}
