package com.buildappswithpaulo.com;

public interface Bank {
     void withdrawMoney(String clientName) throws Exception;
}
