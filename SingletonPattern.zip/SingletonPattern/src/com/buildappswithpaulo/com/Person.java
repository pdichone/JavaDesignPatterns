package com.buildappswithpaulo.com;

public class Person {

    public Person() {
        System.out.println("Creating a person");
    }
}
