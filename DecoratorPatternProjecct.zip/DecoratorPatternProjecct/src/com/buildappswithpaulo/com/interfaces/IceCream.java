package com.buildappswithpaulo.com.interfaces;

public interface IceCream {
    double cost();
}
