package com.buildappswithpaulo.com;

public interface Expression {
    String interpreter(InterpreterContext interpreterContext);
}
