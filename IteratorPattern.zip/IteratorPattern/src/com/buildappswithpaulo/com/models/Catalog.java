package com.buildappswithpaulo.com.models;

import java.util.Iterator;

public interface Catalog {
    public Iterator createIterator();
}
