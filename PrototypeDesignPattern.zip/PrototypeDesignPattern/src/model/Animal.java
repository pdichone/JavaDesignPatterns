package model;

public interface Animal extends Cloneable  {
     Animal clone();

}
