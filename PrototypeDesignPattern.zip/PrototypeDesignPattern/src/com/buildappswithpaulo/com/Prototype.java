package com.buildappswithpaulo.com;

public interface Prototype {
    Prototype clone();

}
