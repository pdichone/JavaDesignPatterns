package com.buildappswithpaulo.com.interfaces;

public interface Command {
      void execute();
}
