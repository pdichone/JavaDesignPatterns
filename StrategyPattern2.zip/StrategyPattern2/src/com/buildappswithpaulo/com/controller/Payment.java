package com.buildappswithpaulo.com.controller;

public interface Payment {
    public void pay(int amount);
}
