package com.buildappswithpaulo.com.model;

public class CheeseBurger extends Hamburger {
}
