package com.buildappswithpaulo.com.model;

public class GreekBurger extends Hamburger {
}
