package com.buildappswithpaulo.com.model;

public class MeatLover extends Hamburger {
}
