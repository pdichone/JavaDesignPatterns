package com.buildappswithpaulo.com.model;

public class VeggieBurger extends Hamburger {
}
