package com.buildappswithpaulo.com.model;

public class BunLessBurger extends Hamburger {
}
