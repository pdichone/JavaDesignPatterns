package com.buildappswithpaulo.com.model;

public class MozambicanVeggieBurger extends Hamburger {
}
