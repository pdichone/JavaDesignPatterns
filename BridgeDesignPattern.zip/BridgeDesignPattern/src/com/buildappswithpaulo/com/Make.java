package com.buildappswithpaulo.com;

public class Make implements WorkShop {

    @Override
    public void make() {
        System.out.println("Making...");
    }
}
