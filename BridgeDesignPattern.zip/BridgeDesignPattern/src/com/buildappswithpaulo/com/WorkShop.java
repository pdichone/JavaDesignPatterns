package com.buildappswithpaulo.com;

interface WorkShop {
     void make();
}
