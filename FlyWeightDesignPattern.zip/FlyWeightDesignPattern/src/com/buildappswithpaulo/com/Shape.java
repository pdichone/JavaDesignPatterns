package com.buildappswithpaulo.com;

public interface Shape {
    void draw();
}
